﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04
{
    internal class Triangulo
    {
        private double a1;
        private double b2;
        private double resultado;

        public void setA1(double a)
        {
            a1 = a;
        }
        public void setB2(double b)
        {
            b2 = b;
        }
        public double getA1()
        {
            return a1;
        }
        public double getB2()
        {
            return b2;
        }
        public void operacao()
        {
            resultado = b2 * a1 / 2;
        }
        public double getResultado()
        {
            return resultado;
        }



    }
}
