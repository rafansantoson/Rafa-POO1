﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Milha milha1;
            milha1 = new Milha();

            Console.WriteLine("Converta seu valor em quilometros p/milha maritima");
            Console.WriteLine("Digite um valor em Milha Marítima: ");
            milha1.setValor(double.Parse(Console.ReadLine()));

            milha1.operacao();

            Console.WriteLine("Resultado em Quilômetro: {0}", milha1.getResultado());

        }
    }
}
