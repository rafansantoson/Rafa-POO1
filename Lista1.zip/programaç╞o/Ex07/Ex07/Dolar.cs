﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex07
{
    internal class Dolar
    {
        private double valor1;
        private double valor2;
        private double resultado;

        public void setValor1(double v)
        {
            valor1 = v;
        }
        public void setValor2(double v)
        {
            valor2 = v;
        }
        public double getValor1()
        {
            return valor1;
        }
        public double getValor2()
        {
            return valor2;
        }
        public void operacao()
        {
            resultado = valor1 * valor2;
        }
        public double getResultado()
        {
            return resultado;
        }
    }
}
